<div class="error"></div>
<div class="success"></div>
<form action="" id="frm-mobile-verification">
    <div class="form-row">
        <label>OTP is sent to Your Mobile Number</label>
    </div>

    <div class="form-row">
        <input type="number" name="" id="mobileotp" class="form-input" placeholder="Enter The OTP">
    </div>

    <div class="row">
        <input type="button" id="verify" class="btnVerify" value="Verify" onClick="verifyOTP();">
    </div>
</form>