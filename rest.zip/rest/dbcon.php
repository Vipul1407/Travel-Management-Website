<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'restaurentms';

// Create connection
$sql = mysqli_connect($host, $username, $password, $database);

// Check connection
// if (!$conn) {
//     die("Connection failed: " . mysqli_connect_error());
// } else {
//     echo "Connected successfully";
// }

// Rest of your code goes here...

?>
